package helloworld;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.twilio.sdk.TwilioRestClient;
import com.twilio.sdk.TwilioRestException;
import com.twilio.sdk.resource.factory.MessageFactory;
import com.twilio.sdk.resource.instance.Message;
public class SMSHelper {
	
	 private static final Logger log = LoggerFactory.getLogger(SMSHelper.class);
    
        public static final String ACCOUNT_SID = "AC074a42c7b411adfbcee44bef084a084f";
        public static final String AUTH_TOKEN = "79b6711981fc51c0f80a6407e2accfd6";

        public static String sendSMS() throws TwilioRestException {
            TwilioRestClient client = new TwilioRestClient(ACCOUNT_SID, AUTH_TOKEN);

            long opt = System.currentTimeMillis();
            String str = String.valueOf(opt);
            log.info("THe full text is " + str );
            // Build the parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            //params.add(new BasicNameValuePair("To", "+19802678225"));
            params.add(new BasicNameValuePair("To", "+17049967084"));
            params.add(new BasicNameValuePair("From", "+12176190649"));
            params.add(new BasicNameValuePair("Body", "Your OTP is " + str.substring(9, 13)));

            MessageFactory messageFactory = client.getAccount().getMessageFactory();
            Message message = messageFactory.create(params);
            log.info(message.getSid());
            return str.substring(9,13);
        }
    
        public static String sendSMS(String msg) throws TwilioRestException {
            TwilioRestClient client = new TwilioRestClient(ACCOUNT_SID, AUTH_TOKEN);

      
     
    
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("To", "+19802678225"));
            params.add(new BasicNameValuePair("From", "+12176190649"));
            params.add(new BasicNameValuePair("Body", msg));

            MessageFactory messageFactory = client.getAccount().getMessageFactory();
            Message message = messageFactory.create(params);
            log.info(message.getSid());
            return msg;
        }
}
