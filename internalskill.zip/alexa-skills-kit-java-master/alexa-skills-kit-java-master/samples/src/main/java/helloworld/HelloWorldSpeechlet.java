/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
 */
package helloworld;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazon.speech.slu.Intent;
import com.amazon.speech.slu.Slot;
import com.amazon.speech.speechlet.IntentRequest;
import com.amazon.speech.speechlet.LaunchRequest;
import com.amazon.speech.speechlet.Session;
import com.amazon.speech.speechlet.SessionEndedRequest;
import com.amazon.speech.speechlet.SessionStartedRequest;
import com.amazon.speech.speechlet.Speechlet;
import com.amazon.speech.speechlet.SpeechletException;
import com.amazon.speech.speechlet.SpeechletResponse;
import com.amazonaws.util.json.JSONArray;
import com.amazonaws.util.json.JSONException;
import com.amazonaws.util.json.JSONObject;

public class HelloWorldSpeechlet implements Speechlet {
    private static final Logger log = LoggerFactory.getLogger(HelloWorldSpeechlet.class);

    @Override
    public void onSessionStarted(final SessionStartedRequest request, final Session session) throws SpeechletException {
        log.info("onSessionStarted requestId={}, sessionId={}", request.getRequestId(),session.getSessionId());

    }

    @Override
    public SpeechletResponse onLaunch(final LaunchRequest request, final Session session)throws SpeechletException {
        log.info("onLaunch requestId={}, sessionId={}", request.getRequestId(), session.getSessionId());
        return SpeechUtil.getWelcomeResponse();
    }
    
    @Override
    public void onSessionEnded(final SessionEndedRequest request, final Session session)throws SpeechletException {
        log.info("onSessionEnded requestId={}, sessionId={}", request.getRequestId(),session.getSessionId());
    }

    @Override
    public SpeechletResponse onIntent(final IntentRequest request, final Session session)throws SpeechletException {
        log.info("onIntent requestId={}, sessionId={}", request.getRequestId(),session.getSessionId());
        try{
             Intent intent = request.getIntent();
             String intentName = (intent != null) ? intent.getName() : null;
             
             log.info("The intent name is : "+ intentName);
             
             Map<String,String> hashmap = new HashMap<String,String>();
             hashmap.put("iraweek", "442");
             hashmap.put("iraweeks", "442");
             hashmap.put("brokerageweek", "237");
             hashmap.put("tppweek","16");
             hashmap.put("managedweek", "16");
             hashmap.put("iramonth", "2245");
             hashmap.put("brokeragemonth", "1028");
             hashmap.put("tppmonth", "51");
             hashmap.put("managedmonth","174");
             hashmap.put("iraquarter", "8084");
             hashmap.put("brokeragequarter", "3345");
             hashmap.put("tppquarter", "179");
             hashmap.put("managedquarter", "1317");
             hashmap.put("irasubmittoday","57");
             hashmap.put("brokeragesubmittoday", "34");
             hashmap.put("tppsubmittoday", "3");
             hashmap.put("managedsubmittoday", "21");
             hashmap.put("irahitstoday","138");
             hashmap.put("brokeragehitstoday", "20");
             hashmap.put("tpphitstoday", "4");
             hashmap.put("managedhitstoday","21");
             
             if(!"OTP".equals(intentName)){
             	  session.setAttribute("IntentName", intentName);
             	  String slot =  getPromptFromRequest(request, session);
             	  session.setAttribute("Slot", slot);	   
             }
             
             if("HOME".equals(intentName)){
             	log.info("Speaking welcome Message");
             	return SpeechUtil.createAskResponse("Welcome to TIAA", "Welcome to T,I,A,A. How can I help you today?");
             }
             
             if("ShowDashBoardIntent".equals(intentName)){
             	log.info("Show DashBoard intent");
             	String requestCommand = getPromptFromRequest(request,session);
             	log.info("printing slot--> "+ requestCommand);
             	String response = null;
             	if(requestCommand!=null){
             		requestCommand = requestCommand.trim();
             		response = "Showing "+ requestCommand + " dashboard";
             		if("ira".equalsIgnoreCase(requestCommand)){
             			requestCommand = "oneira";
             		}else{
             			requestCommand = requestCommand.toLowerCase();
             		}
             	}else{
             		response = "Showing dashboard";
             		requestCommand = "oneira";
             	}
         		StringBuilder builder = new StringBuilder();
         		builder.append("show");
         		builder.append(" ");
         		builder.append(requestCommand);
         		log.info(builder.toString());		
     			WebServiceHelper.makeTiaaServiceCallForDashBoard("DashBoard intent", builder.toString(), "POST", "retrieve-speech");
         		return SpeechUtil.createAskResponse("Show DashBoard", response);
             	
             }
             
             if("ShowOtherTabIntents".equalsIgnoreCase(intentName)){
            	 String requestCommand = getPromptFromRequest(request,session);
            	 StringBuilder response = new StringBuilder("Showing");
            	 if(requestCommand.contains("drop")){
            		 requestCommand = "tpp drop off rate";
            	 }else if(requestCommand.contains("ira")){
            		 requestCommand = "ira in flows";
            	 }else if("stats".equalsIgnoreCase(requestCommand)){
            		 requestCommand = "all stats";
            	 }
            	 
            	 response.append(requestCommand);
            	 StringBuilder builder = new StringBuilder();
          		builder.append(requestCommand);
          		log.info(builder.toString());		
      			WebServiceHelper.makeTiaaServiceCallForDashBoard("DashBoard intent", builder.toString(), "POST", "retrieve-speech");
          		return SpeechUtil.createAskResponse("Show DashBoard", response.toString());
            	 //uao metrics
            	 //tpp metrics
            	 //tpp drop off rate
            	 // ira in flows
            	 // all stats
             }
             if("ShowSubmitIntents".equalsIgnoreCase(intentName)){
            	 String requestCommand = getPromptFromRequest(request,session);
            	 requestCommand = requestCommand.toLowerCase();
            	 String value = hashmap.get(requestCommand+"submittoday");
            	 StringBuilder response = new StringBuilder(value).append(" ");
            	 StringBuilder builder = new StringBuilder("show ");
            	 builder.append(requestCommand.toLowerCase()).append(" ")
            	 .append("accounts opened today").append("|").append(value);
            	 response.append(requestCommand).append(" accounts got submitted today");
            	 
           
          		log.info(builder.toString());		
      			WebServiceHelper.makeTiaaServiceCallForDashBoard("DashBoard intent", builder.toString(), "POST", "retrieve-speech");
          		return SpeechUtil.createAskResponse("Show DashBoard", response.toString());
            	 
             }
             
             if("ShowHitsIntents".equalsIgnoreCase(intentName)){
            	 String requestCommand = getPromptFromRequest(request,session);
            	 requestCommand = requestCommand.toLowerCase();
            	 String value = hashmap.get(requestCommand+"hitstoday");
            	 StringBuilder response = new StringBuilder(value).append(" ");
            	 StringBuilder builder = new StringBuilder("show ");
            	
            	 builder.append("total ").append(requestCommand.toLowerCase()).append(" hits for today")
            	 
            	 .append("|").append(value);
            	response.append(" hits today for ");
            	 response.append(requestCommand);
            	 
           
          		log.info(builder.toString());		
      			WebServiceHelper.makeTiaaServiceCallForDashBoard("DashBoard intent", builder.toString(), "POST", "retrieve-speech");
          		return SpeechUtil.createAskResponse("Show DashBoard", response.toString());
            	 
             }
            
             if("ShowAlertsIntent".equalsIgnoreCase(intentName)){
            	 String requestCommand1 = getPromptsFromRequest(request,session);
            	 Map<String,String> p = getPrompts1FromRequest(request, session);
            	 log.info(requestCommand1);
            	 
            	 String value = hashmap.get(p.get("TIAAShowDashBoardSlot").toLowerCase()+p.get("TIAAAlertSlot").toLowerCase());
            	 StringBuilder response = new StringBuilder(value).append(" ");
            	 StringBuilder builder = new StringBuilder("show ");
            	 builder.append(p.get("TIAAShowDashBoardSlot").toLowerCase()).append(" ")
            	 .append("last ");
            	 builder.append(p.get("TIAAAlertSlot").toLowerCase()).append("|").append(value);
            	 response.append(p.get("TIAAShowDashBoardSlot").toLowerCase())
            	 .append(" accounts got opened last ").append(p.get("TIAAAlertSlot").toLowerCase());
            	 
          		log.info(builder.toString());		
      			WebServiceHelper.makeTiaaServiceCallForDashBoard("DashBoard intent", builder.toString(), "POST", "retrieve-speech");
          		return SpeechUtil.createAskResponse("Show DashBoard", response.toString());
            	 //uao metrics
            	 //tpp metrics
            	 //tpp drop off rate
            	 // ira in flows
            	 // all stats
             }
             
             
             if("ShowDetailsDashBoardIntent".equalsIgnoreCase(intentName)){
             	log.info("Show Details DashBoard intent");
             	String requestCommand = getPromptFromRequestForTIAA(request,session);
         		StringBuilder builder = new StringBuilder();
         		builder.append("Show");
         		builder.append(" ");
         		builder.append("details");
         		builder.append(" ");
         		builder.append(requestCommand);
         		log.info(builder.toString());
     			WebServiceHelper.makeTiaaServiceCallForDashBoard("DashBoard intent", builder.toString(), "POST", "retrieve-speech");
             	return SpeechUtil.createAskResponse("Show Details Dashboard", "Showing details of " + requestCommand);
             }
             
             if("ShowSunBurstDashBoardIntent".equalsIgnoreCase(intentName)){
             	log.info("Show sunburst DashBoard intent");
             	String requestCommand = getPromptFromRequestForTIAA(request,session);
         		StringBuilder builder = new StringBuilder();
         		builder.append("sunburst");
         		builder.append(" ");
         		builder.append(requestCommand);
         		log.info(builder.toString());	
     			WebServiceHelper.makeTiaaServiceCallForDashBoard("SunBurst intent", builder.toString(), "POST", "retrieve-speech");
             	if("IRA".equalsIgnoreCase(requestCommand.trim())){
             		requestCommand = "(I R A)";
             	}
             	if("brokerage ira".equalsIgnoreCase(requestCommand.trim())){
             		requestCommand = "Brokerage(I R A)";
             	}
             	log.info(requestCommand);
     			return SpeechUtil.createAskResponse("Show sun burst Dashboard", "Showing sun burst of " + requestCommand);
             }
             
             if("TIAAHelpIntent".equalsIgnoreCase(intentName)){
             	log.info("Launch TIAA Help intent");
             	String requestCommand = getPromptFromRequestForTIAA(request,session);
             	if(requestCommand.trim().equalsIgnoreCase("service now")){
             		requestCommand = "get it";
             	}
         		StringBuilder builder = new StringBuilder();
         		builder.append("launch");
         		builder.append(" ");
         		builder.append(requestCommand);
         		log.info(builder.toString());	
     			WebServiceHelper.makeTiaaServiceCallForDashBoard("Tiaa Help intent", builder.toString(), "POST", "retrieve-speech");
             	if("FIS".equalsIgnoreCase(requestCommand.trim())){
             		requestCommand = "(F I S)";
             	}
             	if("UD".equalsIgnoreCase(requestCommand.trim())){
             		requestCommand = "(U D)";
             	}
             	log.info(requestCommand);
     			return SpeechUtil.createAskResponsewithDiffPrompt("Launch TIAA Apps", "Launching  " + requestCommand);
             }
             
             
             if("EmailIntent".equalsIgnoreCase(intentName)){
         		session.setAttribute("EmailIntent", "Received");
         		return SpeechUtil.createAskResponse("Ask Receiver", "To whom do you want to send the email ?");
             }
             
             if("EmailToIntent".equalsIgnoreCase(intentName)&& session.getAttribute("EmailIntent")!=null){
            	 log.info(" EmailTo Intent triggered");
            	 String requestCommand = getPromptFromRequestForTIAA(request,session);
              	log.info(requestCommand);    	
              	if(requestCommand!=null && !requestCommand.isEmpty() ){
              		session.setAttribute("EmailTo", requestCommand);
                 	return SpeechUtil.createAskResponse("Ask Subject", "What will be subject of the email for "+ requestCommand);
             	}
             }
             
             
             if("EmailSubjectIntent".equalsIgnoreCase(intentName) && session.getAttribute("EmailTo")!=null){
             	log.info("Subject Email Intent");
             	String requestCommand = getPromptFromRequestForTIAA(request,session);
             	session.setAttribute("Subject", requestCommand);
             	return SpeechUtil.createAskResponse("Ask Message", "What will be message content of the email ?");
             }
             
             
             if("EmailMessageIntent".equalsIgnoreCase(intentName) && session.getAttribute("Subject")!=null){
             	log.info("Email Intent");
             	String requestCommand = getPromptFromRequestForTIAA(request,session);
             	session.setAttribute("Message", requestCommand);
             	JSONObject obj = new JSONObject();
 				obj.put("mailTo", (String)session.getAttribute("EmailTo"));
 				obj.put("mailSubject", (String)session.getAttribute("Subject"));
 				obj.put("mailBody", (String)session.getAttribute("Message"));
         		log.info(obj.toString());	
     			WebServiceHelper.makeTiaaServiceCallForDashBoard("Tiaa Email intent", "send "+obj.toString(), "POST", "retrieve-speech");
             	session.removeAttribute("Message");
             	session.removeAttribute("Subject");
             	
             	session.removeAttribute("EmailIntent");
             	String to = (String)session.getAttribute("EmailTo");
             	session.removeAttribute("EmailTo");
     			return SpeechUtil.createAskResponse("Sending email", "Email sent to "+ to);
             }
             
            
             if("CalendarIntent".equals(intentName)){
             	log.info("Calendar Intent");
             	StringBuilder builder = new StringBuilder();
         		String requestCommand= getPromptFromCalendarRequestForTIAA(request,session);
         		log.info("Request " + requestCommand);
         		session.setAttribute("CalendarRequest", requestCommand);
 				String response = WebServiceHelper.makeTiaaServiceCallForDashBoard("Tiaa Calendar intent", "find "+requestCommand, "POST", "retrieve-speech"); 
 				log.info(response);	
 				JSONObject obj = new JSONObject(response);
 				JSONObject parent = obj.getJSONObject("status").getJSONArray("status").getJSONObject(0);
 				JSONArray meetings = parent.getJSONArray("speechTexts");
 				if(parent.getInt("count")==0){
 					return SpeechUtil.createAskResponse("CalendarDetails", "You dont have any meetings available at this time frame.");
 				}
 				
 				session.setAttribute("CalendarIntent", parent.toString());
 				if(parent.getInt("count")== parent.getInt("index")|| parent.getInt("count")<=3){
 					builder.append("You have "+ parent.getInt("count")+ " meetings at that time ");
 					for(int i=0;i<meetings.length();i++){
 						builder.append(meetings.getJSONObject(i).getString("speechText"));
 						builder.append(". ");
 					}
 				}
 				else{	
 					builder.append("You have "+ parent.getInt("count") +" meetings at this time .  Do you want to know the details ?");
 				}	
             	return SpeechUtil.createAskResponse("CalendarDetails", builder.toString());
             }
             
             if("LateCalendarIntent".equals(intentName)){
             	log.info("Send Late Calendar email Intent");
         		String requestCommand= getPromptFromCalendarRequestForTIAA(request,session);
     			String response = WebServiceHelper.makeTiaaServiceCallForDashBoard("Tiaa Calendar intent", "find "+requestCommand, "POST", "retrieve-speech"); 
     			log.info(response);
     			JSONObject obj = new JSONObject(response);
 				JSONObject parent = obj.getJSONObject("status").getJSONArray("status").getJSONObject(0);
 				JSONArray meetings = parent.getJSONArray("speechTexts");  
 				session.setAttribute("LateMeetingDetails", meetings.toString());
     			if(meetings.length()==1){
     				JSONObject email = new JSONObject();
 	        		email.put("mailTo", meetings.getJSONObject(0).getString("organizerFullName"));
 	        		email.put("meetingTitle", meetings.getJSONObject(0).getString("meetingTitle"));
 	        		email.put("organizerFirstName", meetings.getJSONObject(0).getString("organizerFirstName"));	
 	        		log.info(obj.toString());
 	    			WebServiceHelper.makeTiaaServiceCallForDashBoard("Tiaa Email intent", "late "+email.toString(), "POST", "retrieve-speech");
 	    			return SpeechUtil.createAskResponse("Sending email", "Email sent to "+ meetings.getJSONObject(0).getString("organizerFirstName"));
     			}else{
     				StringBuilder sb = new StringBuilder();
     				sb.append("You have "+ meetings.length()+ " meetings at this time. To which one do you want to send an email?");
     				for(int i=0;i<meetings.length();i++){
     					sb.append("Say "+ String.valueOf(i+1) +" for ");
     					
     					sb.append(meetings.getJSONObject(i).getString("speechText"));
     					sb.append(" ");
     				}
     				log.info(sb.toString());
     				return SpeechUtil.createAskResponse("Late Email Confirmation", sb.toString());
     			}
         			
             }
             
             if("LateCalendarIntentDetails".equals(intentName)&& session.getAttribute("LateMeetingDetails")!=null){
            	 String pr = getPromptFromRequest( request, session);
            	 Integer i =Integer.valueOf(pr);
            	 JSONArray meetings = new JSONArray((String)session.getAttribute("LateMeetingDetails"));
            	 JSONObject email = new JSONObject();
	        		email.put("mailTo", meetings.getJSONObject(i-1).getString("organizerFullName"));
	        		email.put("meetingTitle", meetings.getJSONObject(i-1).getString("meetingTitle"));
	        		email.put("organizerFirstName", meetings.getJSONObject(i-1).getString("organizerFirstName"));	
	        		
	    			WebServiceHelper.makeTiaaServiceCallForDashBoard("Tiaa Email intent", "late "+email.toString(), "POST", "retrieve-speech");
	    			return SpeechUtil.createAskResponse("Sending email", "Email sent to "+ meetings.getJSONObject(i-1).getString("organizerFirstName"));
             }
             if("AMAZON.StopIntent".equals(intentName)){
             	return SpeechUtil.createTellResponse("Stop","Thank you. Have a nice day");
             }
           
             if("DIALOG".equals(intentName)){
             	return SpeechUtil.createTellResponse("Thankyou", "Happy to Help. Have a great day!!");
             }
             
             if("PROMPT".equals(intentName) && session.getAttribute("CalendarIntent")!=null){
             	String pr = getPromptFromRequest(request, session);	
             	StringBuilder builder = new StringBuilder();
             	if("yes".equalsIgnoreCase(pr)){
             		JSONObject parent = new JSONObject((String)session.getAttribute("CalendarIntent"));
             		JSONArray meetings = parent.getJSONArray("speechTexts");
				
				for(int i=0;i<meetings.length();i++){
					builder.append(meetings.getJSONObject(i).getString("speechText"));
					builder.append(". ");
				}
				if(parent.getInt("count")>meetings.length()){
					session.setAttribute("CalendarReIntent", parent.toString());
					session.removeAttribute("CalendarIntent");
					builder.append("Do you want to know the details of the remaining meetings?");
				}
     			return SpeechUtil.createAskResponse("PROMPTRESPONSE Calendar", builder.toString());
             	}else{
             		builder.append("Okay. Thank you");
             	}
             	return SpeechUtil.createTellResponse("PROMPTRESPONSE Calendar", builder.toString());
             }
             
             if("PROMPT".equals(intentName)&& session.getAttribute("CalendarReIntent") !=null){
            	 String pr = getPromptFromRequest(request, session);	
              	StringBuilder builder = new StringBuilder();
              	JSONObject requestCommand = new JSONObject((String)session.getAttribute("CalendarReIntent"));
              	JSONObject jsonrequest = new JSONObject((String)session.getAttribute("CalendarRequest"));
              	jsonrequest.put("index", String.valueOf(requestCommand.getInt("index")));
            	 if("yes".equalsIgnoreCase(pr)){
            		 String response = WebServiceHelper.makeTiaaServiceCallForDashBoard("Tiaa Calendar intent", "find "+jsonrequest.toString(), "POST", "retrieve-speech"); 
      				log.info(response);	
      				JSONObject obj = new JSONObject(response);
      				JSONObject parent = obj.getJSONObject("status").getJSONArray("status").getJSONObject(0);
      				
      				JSONArray meetings = parent.getJSONArray("speechTexts");
      				for(int i=0;i<meetings.length();i++){
    					builder.append(meetings.getJSONObject(i).getString("speechText"));
    					builder.append(". ");
    				}
    				if(parent.getInt("count")>parent.getInt("index")){
    					session.setAttribute("CalendarReIntent", parent.toString());
    					
    					builder.append("Do you want to know the details of the remaining meetings?");
    				}
         			return SpeechUtil.createAskResponse("PROMPTRESPONSE Calendar", builder.toString());
                 	}else{
                 		builder.append("Okay. Thank you");
                 	}
                 	return SpeechUtil.createTellResponse("PROMPTRESPONSE Calendar", builder.toString());
            	 }
             
             if("IRAIntent".equalsIgnoreCase(intentName)){
            	 try {
					String response = WebServiceHelper.makeTiaaServiceCallForDashBoard("IRAIntent",getPromptFromIRAEnrollmentRequestForTIAA(request,session) , "POST", "get-product-count");
					log.info(response);
					JSONObject obj = new JSONObject(response);
					JSONArray result = obj.getJSONArray("result");
					if(result.length()>0){
						StringBuilder sb = new StringBuilder();
						String speech = getSpeechFilterForIRACount("One IRA enrollments ",session);
						if(speech ==null){
							sb.append("The total number of One IRA enrollments  ");
						}else{
							sb.append(speech);
						}
						sb.append(" is ");
						StringBuilder inflight= null;
						StringBuilder completed = null;	
						if(result.length()==1){		
							inflight = new StringBuilder();
							inflight.append(result.getJSONObject(0).getString("count"));
							inflight.append(". Out of which ");
							inflight.append(result.getJSONObject(0).getString("count"));
							inflight.append(" are "+ result.getJSONObject(0).getString("enrollmentStatus")+ " transactions");	
							sb.append(inflight);
							return SpeechUtil.createAskResponse("One IRA Enrollment Count", sb.toString());
						}	
						int total = 0;
						for(int i=0;i<result.length();i++){
							total = total + Integer.parseInt(result.getJSONObject(i).getString("count"));	
							if(!"Completed".equalsIgnoreCase(result.getJSONObject(i).getString("enrollmentStatus"))){
								inflight = new StringBuilder();
								inflight.append(" and ");
								inflight.append(result.getJSONObject(i).getString("count"));
								inflight.append(" are inflight.");
							}else{
								completed = new StringBuilder();
								completed.append(". Out of which ");
								completed.append(result.getJSONObject(i).getString("count"));
								completed.append(" are completed  ");
							}
						}
						sb.append(total);
						sb.append(completed);
						sb.append(inflight);
						log.info(sb.toString());
						return SpeechUtil.createAskResponse("One IRA Enrollment Count", sb.toString());
					}else{
						return SpeechUtil.createAskResponse("One IRA Enrollment Count", "There are no enrollments at this time frame.");
					}		
            	 } catch (Exception e) {
					return SpeechUtil.createTellResponse("One IRA Enrollment Count", "I am sorry I am unable to help you at this moment. Please come back later. Thank you.");	
				}
             }
             
             if("IRAFundIntent".equalsIgnoreCase(intentName)){
            	 JSONObject obj = new JSONObject(getPromptFromIRAEnrollmentRequestForTIAA(request,session));
            	 obj.put("type", "Funding");
            	 log.info(obj.toString());
            	 try {
					String response = WebServiceHelper.makeTiaaServiceCallForDashBoard("IRAIntent",obj.toString() , "POST", "get-product-count");
					log.info(response);
					JSONObject responseJson = new JSONObject(response);
					StringBuilder sb = new StringBuilder();
					String speech = getSpeechFilterForIRACount("One IRA accounts funded  ",session);
					
					if(speech ==null){
						sb.append("One IRA accounts funded is ");
					}else{
						sb.append(speech);
						sb.append(" is ");
					}
					
					if(responseJson.has("count")){
						sb.append(responseJson.getString("count"));
						return SpeechUtil.createAskResponse("One IRA Funding Count", sb.toString());
					}else{
						return SpeechUtil.createAskResponse("One IRA Funding Count", "I am sorry I am unable to help you at this moment. Please come back later. Thank you.");
					}
            	 } catch (Exception e) {
					return SpeechUtil.createAskResponse("One IRA Funding Count", "I am sorry I am unable to help you at this moment. Please come back later. Thank you.");
				}
            	 
             }
           else{
             	return SpeechUtil.createAskResponse("DefaultSpeech", "I am not sure how to help you on this.");
             }
        }catch(JSONException e){
        	log.error(e.getMessage());
        	e.printStackTrace();
        } catch (ParseException e) {
			e.printStackTrace();
		}
        return SpeechUtil.createTellResponse("DefaultSpeech", "I am not sure how to help you on this.");
    }
    
    
    public String getSpeechFilterForIRACount(String start ,Session session) throws JSONException{
    	StringBuilder sb = null;
    	if(session.getAttribute("IRACountsHistory")!=null){
    		JSONObject obj = new JSONObject((String)session.getAttribute("IRACountsHistory"));
    		sb= new StringBuilder(start);
    		if(obj.has("channel")){
    			sb.append("from ");
    			if("Web - Individual".equalsIgnoreCase(obj.getString("channel"))){
    				sb.append("direct");
    				
    			}else{
    				sb.append("agent");
    			}
    			sb.append(" sales");
    		}
    		
    		if(obj.has("state")){
    			sb.append("in ");
    			sb.append(obj.getString("state"));
    			sb.append(" state");
    		}	
    		sb.append(getDateSpeechText(obj.has("year") ? obj.getString("year"): null,
    				obj.has("month") ? obj.getString("month"): null,
    						obj.has("date") ? obj.getString("date"): null));
    		
    		return sb.toString();
    	}
    	return null;
    }
    
    public String getPromptFromRequest(IntentRequest request,Session session){
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	String slotValue=null;
   
        for(Map.Entry<String, Slot> entry : slotMap.entrySet())
        {  
            Slot slot = (Slot)entry.getValue();
            log.info(slot.getValue());
            slotValue = slot.getValue();
        }
        
    	return slotValue;
    }
    
    public String getPromptsFromRequest(IntentRequest request,Session session){
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	StringBuilder slotValue= new StringBuilder();
   
        for(Map.Entry<String, Slot> entry : slotMap.entrySet())
        {  
            Slot slot = (Slot)entry.getValue();
            log.info(slot.getValue());
            slotValue.append(slot.getValue());
        }
        
    	return slotValue.toString();
    }
    public Map<String,String> getPrompts1FromRequest(IntentRequest request,Session session){
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	Map<String,String> map = new HashMap<>();
   
        for(Map.Entry<String, Slot> entry : slotMap.entrySet())
        {  
            Slot slot = (Slot)entry.getValue();
            log.info(slot.getValue());
            map.put(slot.getName(),slot.getValue());
        }
        
    	return map;
    }

    public String getPromptFromIRAEnrollmentRequestForTIAA(IntentRequest request,Session session) throws JSONException,ParseException{
    	JSONObject requestForTIAA =null;
    	if(session.getAttribute("IRACountsHistory")!=null){
    		requestForTIAA = new JSONObject((String)session.getAttribute("IRACountsHistory"));
    	}else{
    		requestForTIAA = new JSONObject();
    	} 	
    	HashSet<String> callCenter = new HashSet<String>();
    	callCenter.add("call center");
    	callCenter.add("agent assisted");
    	callCenter.add("agent");
    	callCenter.add("call");
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	for(Map.Entry<String, Slot> entry:slotMap.entrySet()){
    		Slot slot = (Slot)entry.getValue();
    		if("State".equalsIgnoreCase(slot.getName()) && slot.getValue()!=null){
    			requestForTIAA.put("state", slot.getValue());
    		}
    		if("Channel".equalsIgnoreCase(slot.getName()) && slot.getValue()!=null){
    			if(callCenter.contains(slot.getValue())){
    				requestForTIAA.put("channel", "Call Center");
    			}else{
    				try {
						int year = Integer.parseInt(slot.getValue());
						requestForTIAA.put("year", String.valueOf(year));
					} catch (NumberFormatException e) {
						requestForTIAA.put("channel", "Web - Individual");
					}
    				
    			}
    		}
    		if("Date".equalsIgnoreCase(slot.getName()) && slot.getValue()!=null){
    			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				StringBuilder date = new StringBuilder(slot.getValue());
				Date d;
				try {
					d = df.parse(date.toString());
					Calendar gc = new GregorianCalendar();
					gc.setTime(d);
					requestForTIAA.put("date", String.valueOf(gc.get(Calendar.DAY_OF_MONTH)));
					requestForTIAA.put("month", String.valueOf(gc.get(Calendar.MONTH)+1));
					requestForTIAA.put("year", String.valueOf(gc.get(Calendar.YEAR)));
				} catch (Exception e) {
					log.info(e.getMessage());
					try {
						SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM");
						StringBuilder date1 = new StringBuilder(slot.getValue());
						d = df1.parse(date1.toString());
						Calendar gc = new GregorianCalendar();
						gc.setTime(d);
						requestForTIAA.put("month", String.valueOf(gc.get(Calendar.MONTH)+1));
						requestForTIAA.put("year", String.valueOf(gc.get(Calendar.YEAR)));
					} catch (Exception e1) {
						log.info(e.getMessage());
						requestForTIAA.put("year", slot.getValue());
					}
	    			
					
				}
				
    		}
    		if("Year".equalsIgnoreCase(slot.getName()) && slot.getValue()!=null){	
				requestForTIAA.put("year", slot.getValue());
    		}
    	}
    	session.setAttribute("IRACountsHistory", requestForTIAA.toString());
    	System.out.println(requestForTIAA.toString());
    	return requestForTIAA.toString();
    }

  
    
    public String getPromptFromCalendarRequestForTIAA(IntentRequest request,Session session) throws JSONException, ParseException{
    	JSONObject calendarObject = new JSONObject();
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	for(Map.Entry<String, Slot> entry:slotMap.entrySet()){
    		Slot slot = (Slot)entry.getValue();
    		if("CalendarDateSlot".equalsIgnoreCase(slot.getName())){
    			if(slot.getValue()!=null){
    				calendarObject.put("startDate", slot.getValue());	
    			}else{
    				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    				Date date = new Date();
    				calendarObject.put("startDate", dateFormat.format(date));
    			}
    		}
    		if("CalendarTimeSlot".equalsIgnoreCase(slot.getName())){
    			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    			if(slot.getValue()!=null){
    				StringBuilder date = new StringBuilder(calendarObject.getString("startDate")).append(" ").append(slot.getValue());
    				Date d = df.parse(date.toString());
    				Calendar gc = new GregorianCalendar();
    				gc.setTime(d);
    				gc.add(Calendar.MINUTE, 15);
    				Date resultdate = new Date(gc.getTimeInMillis());
    				calendarObject.put("startDate", date.toString());
    				calendarObject.put("endDate", df.format(resultdate));
    			}else{
    				StringBuilder date = new StringBuilder(calendarObject.getString("startDate")).append(" ").append("09:00");
    				Date d = df.parse(date.toString());
    				Calendar gc = new GregorianCalendar();
    				gc.setTime(d);
    				gc.add(Calendar.HOUR,8);
    				Date resultdate = new Date(gc.getTimeInMillis());
    				calendarObject.put("startDate", date.toString());
    				calendarObject.put("endDate", df.format(resultdate));
    			}
    		}
    	}
    	calendarObject.put("index", "0");
    	return calendarObject.toString();
    } 
    public String getTIAASlotFactory(IntentRequest request,Session session){
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	if(!slotMap.isEmpty()){
    		 for(Map.Entry<String, Slot> entry : slotMap.entrySet())
             {  
                 Slot slot = (Slot)entry.getValue();
                  if(slot.getValue()!=null && "map".equalsIgnoreCase(slot.getValue())){
                 	return getMapFromRequestForTIAA( request, session);
                 	 
                  }
             }
    		
    	}
    	return getPromptFromRequestForTIAA(request, session);
    }
    public String getMapFromRequestForTIAA(IntentRequest request,Session session){
    	Map<String, Slot> slotMap = request.getIntent().getSlots();

    	if(!slotMap.isEmpty()){
    		StringBuilder builder = new StringBuilder();
            for(Map.Entry<String, Slot> entry : slotMap.entrySet())
            {  
                Slot slot = (Slot)entry.getValue();
                 if(slot.getValue()!=null){
                	 builder.append(slot.getValue());
                	 builder.append(" ");
                	 
                 }
            }
            log.info("Created command is " + builder.toString());
            return builder.toString();
    	}
    	
    	return null;
    }
    
    public String getDateSpeechText(String year,String month,String date){
    	if(null !=year && !year.isEmpty()){
    		if(null!=date && !date.isEmpty()){
    			Calendar cal = Calendar.getInstance();
    			int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
    			if( dayOfMonth == Integer.parseInt(date)){
    				return "submitted today ";
    			}else if((dayOfMonth -1)== Integer.parseInt(date)){
    				return "submitted yesterday ";
    			}
    		}else if(null !=month && !month.isEmpty()){
    			String months[] = new DateFormatSymbols().getMonths();
    			String monthName = months[Integer.parseInt(month)-1];
    			return "submitted in the month of "+ monthName + " "; 
    		}else{
    			return "submitted in " + year;
    		}
    	}
    	return "";
    }
    
    public String getPromptFromRequestForTIAA(IntentRequest request,Session session){
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	boolean yearSlot = false;
    	if(!slotMap.isEmpty()){
    		StringBuilder builder = new StringBuilder();
            for(Map.Entry<String, Slot> entry : slotMap.entrySet())
            {  
                Slot slot = (Slot)entry.getValue();
                 if(slot.getValue()!=null){
                	 builder.append(slot.getValue());
                	 builder.append(" ");
                	 if(slot.getValue().equalsIgnoreCase("2016")){
                		 yearSlot = true;
                	 }
                 }else{
                	 if("ShowDashBoardIntent".equalsIgnoreCase(request.getIntent().getName())&& !yearSlot && !builder.toString().trim().equalsIgnoreCase("dashboard")){
                 		builder.append("2016");
                 	}
                	 return builder.toString();
                 }
            }
            
            if("ShowDashBoardIntent".equalsIgnoreCase(request.getIntent().getName())&& !yearSlot && !builder.toString().trim().equalsIgnoreCase("dashboard")){
        		builder.append("2016");
        	}
            log.info("Created command is " + builder.toString());
            return builder.toString();
    	}
    	
    	return null;
    }
    

}
