package helloworld;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.util.json.JSONException;
import com.amazonaws.util.json.JSONObject;

public class WebServiceHelper {
	private static final Logger log = LoggerFactory.getLogger(WebServiceHelper.class);
	
	
	public static String makeTiaaServiceCallForDashBoard(String intentName,String slotValue,
			String method,String operationUrl) throws JSONException{
		String inputLine= "";
		try {
			StringBuilder urlBuilder = new StringBuilder();
			urlBuilder.append("https://origin-service-devint.test.tiaa-cref.org/private/api/alexa-account/v1/");
			urlBuilder.append(operationUrl);
			URL url = new URL(urlBuilder.toString());
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestMethod(method);
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Accept", "application/json");
			con.setRequestProperty("tiaa-user-ref", "alexa");
			con.setDoOutput(true);
            OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream());
            if("IRAIntent".equalsIgnoreCase(intentName)){
            	writer.write(slotValue.toString());
            }else{
            	JSONObject obj = new JSONObject();
                obj.put("command", slotValue);
                log.info(obj.toString());
                writer.write(obj.toString());
            }  
            writer.flush();
            writer.close();
			BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
			if((inputLine = br.readLine()) !=null){
				return inputLine;
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (ProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return inputLine;
		
	}

}
