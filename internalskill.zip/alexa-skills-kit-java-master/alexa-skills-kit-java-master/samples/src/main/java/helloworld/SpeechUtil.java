package helloworld;

import com.amazon.speech.speechlet.SpeechletResponse;
import com.amazon.speech.ui.PlainTextOutputSpeech;
import com.amazon.speech.ui.Reprompt;
import com.amazon.speech.ui.SimpleCard;

public class SpeechUtil {
	
  public static SpeechletResponse createAskResponse(String title,String speechText){
    SimpleCard card = new SimpleCard();
    card.setTitle(title);
    card.setContent(speechText);
    PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
    speech.setText(speechText);
    Reprompt reprompt = new Reprompt();
    reprompt.setOutputSpeech(speech);
    return SpeechletResponse.newAskResponse(speech, reprompt, card);
    }
  
  public static SpeechletResponse createAskResponsewithDiffPrompt(String title,String speechText){
	    SimpleCard card = new SimpleCard();
	    card.setTitle(title);
	    card.setContent(speechText);
	    PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
	    speech.setText(speechText);
	    PlainTextOutputSpeech re = new PlainTextOutputSpeech();
	    re.setText("Is there anything that I can do to help? ");
	    Reprompt reprompt = new Reprompt();
	    reprompt.setOutputSpeech(re);
	    return SpeechletResponse.newAskResponse(speech, reprompt, card);
	    }
	  
  public static SpeechletResponse createTellResponse(String title,String speechText){
    SimpleCard card = new SimpleCard();
    card.setTitle(title);
    card.setContent(speechText);
    PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
    speech.setText(speechText);
    return SpeechletResponse.newTellResponse(speech, card);
    }
  
  public static SpeechletResponse getWelcomeResponse() {
	 return createAskResponse("TIAA Welcome", "Welcome to (T I A A). How can I help you today?.");  
  }
  public static SpeechletResponse getHelpResponse() { 
	return createAskResponse("HelloWorld", "You can say hello to me!");  
  }
  
  public static SpeechletResponse getHelloResponse() {
	  return createTellResponse("HelloWorld", "HelloWorld");  
  }

}
