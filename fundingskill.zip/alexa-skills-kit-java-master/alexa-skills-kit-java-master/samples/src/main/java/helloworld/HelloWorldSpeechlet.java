/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
 */
package helloworld;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import javax.mail.MessagingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazon.speech.slu.Intent;
import com.amazon.speech.slu.Slot;
import com.amazon.speech.speechlet.IntentRequest;
import com.amazon.speech.speechlet.LaunchRequest;
import com.amazon.speech.speechlet.Session;
import com.amazon.speech.speechlet.SessionEndedRequest;
import com.amazon.speech.speechlet.SessionStartedRequest;
import com.amazon.speech.speechlet.Speechlet;
import com.amazon.speech.speechlet.SpeechletException;
import com.amazon.speech.speechlet.SpeechletResponse;
import com.amazonaws.util.json.JSONArray;
import com.amazonaws.util.json.JSONException;
import com.amazonaws.util.json.JSONObject;
import com.twilio.sdk.TwilioRestException;

public class HelloWorldSpeechlet implements Speechlet {
    private static final Logger log = LoggerFactory.getLogger(HelloWorldSpeechlet.class);

    @Override
    public void onSessionStarted(final SessionStartedRequest request, final Session session) throws SpeechletException {
        log.info("onSessionStarted requestId={}, sessionId={}", request.getRequestId(),session.getSessionId());

    }

    @Override
    public SpeechletResponse onLaunch(final LaunchRequest request, final Session session)throws SpeechletException {
        log.info("onLaunch requestId={}, sessionId={}", request.getRequestId(), session.getSessionId());
        return SpeechUtil.getWelcomeResponse();
    }
    
    @Override
    public void onSessionEnded(final SessionEndedRequest request, final Session session)throws SpeechletException {
        log.info("onSessionEnded requestId={}, sessionId={}", request.getRequestId(),session.getSessionId());
    }

    @Override
    public SpeechletResponse onIntent(final IntentRequest request, final Session session)throws SpeechletException {
        log.info("onIntent requestId={}, sessionId={}", request.getRequestId(),session.getSessionId());
        try{
        	 /*String accessToken=null;
             log.info(new JSONObject(request).toString()); 
         	 accessToken = new JSONObject(session).getJSONObject("user").getString("accessToken");
         	 log.info("AccessToken--> "+ accessToken);
         	 String[] array = accessToken.split("\\.");
         	 byte[] decoded = Base64.getDecoder().decode(array[1]);
         	 log.info(new String(decoded, "UTF-8"));
             log.info(new JSONObject(session).toString());*/
             Intent intent = request.getIntent();
             String intentName = (intent != null) ? intent.getName() : null;
             
             log.info("The intent name is : "+ intentName);
             
             if(!"OTP".equals(intentName)){
             	  session.setAttribute("IntentName", intentName);
             	  String slot =  getPromptFromRequest(request, session);
             	  session.setAttribute("Slot", slot);	   
             }
             
             if("HOME".equals(intentName)){
             	log.info("Speaking welcome Message");
             	return SpeechUtil.createAskResponse("Welcome to TIAA", "Welcome to T,I,A,A. How can I help you today?");
             }
             
           
             if("AMAZON.StopIntent".equals(intentName)){
             	return SpeechUtil.createTellResponse("Stop","Thank you. Have a nice day");
             }
           
             if("DIALOG".equals(intentName)){
             	return SpeechUtil.createTellResponse("Thankyou", "Happy to Help. Have a great day!!");
             }
             
           
             if("FUND".equalsIgnoreCase(intentName) || "TIAA".equalsIgnoreCase(intentName)){
             	if(session.getAttribute("OTP")==null){  	
         			session.setAttribute("OTP", SMSHelper.sendSMS());	   	
                 	return SpeechUtil.createAskResponse("OTP", "Please tell OTP from you phone to proceed");
                 }
             }
            
             if("OTP".equals(intentName)){
             	log.info("Inside OTP");
             	String otp = getPromptFromRequest(request, session);	
             	String sotp = (String)session.getAttribute("OTP");
             	if(!otp.equals(sotp)){
             		return SpeechUtil.createTellResponse("InvalidOTP", "Sorry. You are not authorized to proceed. Please try again");
             	}
             	intentName = (String)session.getAttribute("IntentName");
             }
             log.info("The intent name after OTP is " + intentName);
             
             if("PROMPT".equals(intentName) && session.getAttribute("FundingIntent")!=null){
            	 log.info("inside first prompt");
            	 String pr = getPromptFromRequest(request, session);
            	 if("yes".equalsIgnoreCase(pr)){
            		 session.setAttribute("TargetAccount", "Traditional IRA ");
                	 intentName = "TARGETACCOUNTS";
            	 }else{
            		 return SpeechUtil.createTellResponse("TIAA Balance", "Glad to help. Have a good day");
            	 } 
             }
             if("PROMPT".equals(intentName) && session.getAttribute("AMOUNTDONE")==null){
             	String pr = getPromptFromRequest(request, session);		
             	if(pr.equalsIgnoreCase("yes")){
             		session.setAttribute("AMOUNTDONE", "Yes");
             		String str = String.valueOf(5500);
             		//String str = String.valueOf((Double)session.getAttribute("NewAmount"));
             		session.setAttribute("ContributionAmount", str);	
                	String msg;
						try {
							msg = WebServiceHelper.makeTiaaServiceCall("PROMPTSOURCE", "PROMPTSOURCE",
								WebServiceHelper.buildRequestForServiceCall(session, "linked"), "POST", "retrieve-linked-accounts");
							log.info("Linked accounts" + msg);
							if(msg ==null||msg.isEmpty()){
								log.info("Linked accounts" + AlexaConstants.second_response);
			             		session.setAttribute("LinkedAccounts", AlexaConstants.second_response);
			             		return SpeechUtil.createAskResponse("Source", createMultipleLinkedAccountResponse(AlexaConstants.second_response,session));
							}
							JSONObject temp = new JSONObject(msg);
							if(temp.getJSONArray("linkedBanks")==null|| temp.getJSONArray("linkedBanks").length()==0){
								log.info("Linked accounts" + AlexaConstants.second_response);
			             		session.setAttribute("LinkedAccounts", AlexaConstants.second_response);
			             		return SpeechUtil.createAskResponse("Source", createMultipleLinkedAccountResponse(AlexaConstants.second_response,session));
							}
		             		session.setAttribute("LinkedAccounts", msg);
		             		return SpeechUtil.createAskResponse("Source", createMultipleLinkedAccountResponse(msg,session));
						} catch (Exception e) {
							log.info("Linked accounts" + AlexaConstants.second_response);
		             		session.setAttribute("LinkedAccounts", AlexaConstants.second_response);
		             		return SpeechUtil.createAskResponse("Source", createMultipleLinkedAccountResponse(AlexaConstants.second_response,session));
						}
             		
             	}else{
             		if(session.getAttribute("TargetAccount")!=null){
             			String speechText = "How much do you want to transfer to your "+ (String)session.getAttribute("TargetAccount") + " account";
                 		return SpeechUtil.createAskResponse("AMOUNT", speechText);
             		}
             		
             	
             	}
             }
             if("PROMPT".equals(intentName) && session.getAttribute("AMOUNTDONE")!=null){
             	intentName= "SOURCEACCOUNTS";
             }
             if("SOURCEACCOUNTS".equals(intentName) && (String)session.getAttribute("ContributionAmount")!=null){
             	JSONObject linked=null;
             	
 				linked = new JSONObject((String)session.getAttribute("LinkedAccounts"));
 				String pr = getPromptFromRequest(request, session);
 	         	log.info(pr);
 	         	if(pr.equalsIgnoreCase("yes")){
 	         	JSONObject obj = linked.getJSONArray("linkedBanks").getJSONObject(0);
 	         	session.setAttribute("BankName", obj.getString("bankName"));
 	         	session.setAttribute("RoutingNumber", obj.getString("routingNumber"));
 	         	session.setAttribute("BankAccountType", obj.getString("accountType"));
 	         	session.setAttribute("AccountNumber", obj.getString("accountNumber"));
 	         	session.removeAttribute("LinkedAccounts");
 	         	String msg = null;
				try {
					msg = WebServiceHelper.makeTiaaServiceCall("MDM", "MDM", 
							WebServiceHelper.buildRequestForServiceCall(session, "retriveParticipant"), "POST", "retrieve-participant");
					loadSessionWithParticipantData(session,msg);
	 	         	
				} catch (Exception e) {
					hardCodeWithParticipantData(session);
				}   
				
				String speechText = "Please confirm if you want to transfer " + 
						(String)session.getAttribute("ContributionAmount") +" dollars to your " 
	        				 + (String)session.getAttribute("TargetAccount") + " account ending in (5 7 9 0) from " + obj.getString("bankName").replace("NA", "") + " ending in (3 5 9 9)" ;
	        		 return SpeechUtil.createAskResponse("FINALEVENT", speechText);
 	         	}else{
 	         		int i=0;
 	         		boolean condition = false;
 	         		String bankName = getPromptFromRequest(request, session);
 	         		bankName = bankName.toLowerCase();
 	         		log.info("bankName from slot modified --> "+ bankName);
 	         		JSONArray array1 = new JSONArray((String)session.getAttribute("mlinkedBanks"));
 	         		for(i=0;i<array1.length();i++){
 	         			JSONObject bank = array1.getJSONObject(i);
 	         			String mbankName = bank.getString("bankName").replace("NA", "").replace("&", "and").replace(",", "").toLowerCase();
 	         			log.info("comparing text--> "+ mbankName);
 	         			if(mbankName.contains(bankName)){
 	         				condition = true;
 	         				break;
 	         			}
 	         		}
 	         		if(condition){
 	         			String banks = (String)session.getAttribute("mlinkedBanks");
 	         			JSONArray arrayBank = new JSONArray(banks);
 	         			JSONObject obj = arrayBank.getJSONObject(i);
 	         			session.setAttribute("BankName", obj.getString("bankName"));
 	    	         	session.setAttribute("RoutingNumber", obj.getString("routingNumber"));
 	    	         	session.setAttribute("BankAccountType", obj.getString("accountType"));
 	    	         	session.setAttribute("AccountNumber", obj.getString("accountNumber"));
 	    	         	session.removeAttribute("LinkedAccounts");
 	    	         	session.removeAttribute("mlinkedBanks");
 	    	         	String msg = null;
 	    	         	try {
 	   					msg = WebServiceHelper.makeTiaaServiceCall("MDM", "MDM", 
 	   							WebServiceHelper.buildRequestForServiceCall(session, "retriveParticipant"), "POST", "retrieve-participant");
 	   					loadSessionWithParticipantData(session,msg);
 	   	 	         	
 	   				} catch (Exception e) {
 	   					hardCodeWithParticipantData(session);
 	   				} 
 	         			String speechText = "Please confirm if you want to transfer " + 
 	         					(String)session.getAttribute("ContributionAmount") +" dollars to your " 
     	        				 + (String)session.getAttribute("TargetAccount") + " account ending in (5 7 9 0) from " + bankName + " ending in (3 5 9 9)";
     	        		 return SpeechUtil.createAskResponse("FINALEVENT", speechText);
 	         		}else{
 	         			return SpeechUtil.createAskResponse("Ask Again", "Please tell from which account you want to transfer");
 	         		}
 	         		
 	         	}
     			
             }
             if("FINAL".equals(intentName)){
             	String pr = getPromptFromRequest(request, session);
             	if(pr.equalsIgnoreCase("Confirm")){
             		String response;
					try {
						//rnavduri@tiaa.org
						response = WebServiceHelper.makeTiaaServiceCall("FINALSUBMIT", "FINALSUBMIT", 
								WebServiceHelper.buildRequestForServiceCall(session, "submit"), "POST", "submit-funding");
						if(response== null|| response.isEmpty()){
							long time = System.currentTimeMillis();
		             		SimpleDateFormat sdf = new SimpleDateFormat("MM dd,yyyy");
		             		Date resultdate = new Date(time);
		             		String date = sdf.format(resultdate);
		 					new EmailHelper().sendEmailMessage("rnavduri@tiaa.org",EmailHelper.getSubject(),
		 					EmailHelper.getEmailMessage((String)session.getAttribute("BankName"), (String)session.getAttribute("ProductName"), (String)session.getAttribute("ContributionAmount"), date, "C123455") );
		             		String speechText ="Your funds will be transferred in two business days and a confirmation email has been sent. Thank you.";
		             		return SpeechUtil.createAskResponse("Confirmation", speechText);
						}
						JSONObject temp = new JSONObject(response);
						if(temp.getString("orchestrationID")==null){
							long time = System.currentTimeMillis();
		             		SimpleDateFormat sdf = new SimpleDateFormat("MM dd,yyyy");
		             		Date resultdate = new Date(time);
		             		String date = sdf.format(resultdate);
		 					new EmailHelper().sendEmailMessage("chandrachudeswaran@gmail.com",EmailHelper.getSubject(),
		 					EmailHelper.getEmailMessage((String)session.getAttribute("BankName"), (String)session.getAttribute("ProductName"), (String)session.getAttribute("ContributionAmount"), date, "C123455") );
		             		String speechText ="Your funds will be transferred in two business days and a confirmation email has been sent. Thank you.";
		             		return SpeechUtil.createAskResponse("Confirmation", speechText);
						}
						JSONObject obj = new JSONObject(response);
	             		log.info(obj.toString());
	             		long time = System.currentTimeMillis();
	             		SimpleDateFormat sdf = new SimpleDateFormat("MM dd,yyyy");
	             		Date resultdate = new Date(time);
	             		String date = sdf.format(resultdate);
	 					new EmailHelper().sendEmailMessage("chandrachudeswaran@gmail.com",EmailHelper.getSubject(),
	 					EmailHelper.getEmailMessage((String)session.getAttribute("BankName"), (String)session.getAttribute("ProductName"), (String)session.getAttribute("ContributionAmount"), date, obj.getString("orchestrationID")) );
	             		String speechText ="Your funds will be transferred in two business days and a confirmation email has been sent. Thank you.";
	             		return SpeechUtil.createAskResponse("Confirmation", speechText);
					} catch (Exception e) {
						//JSONObject obj = new JSONObject(response);
	             		//log.info(obj.toString());
	             		long time = System.currentTimeMillis();
	             		SimpleDateFormat sdf = new SimpleDateFormat("MM dd,yyyy");
	             		Date resultdate = new Date(time);
	             		String date = sdf.format(resultdate);
	 					new EmailHelper().sendEmailMessage("chandrachudeswaran@gmail.com",EmailHelper.getSubject(),
	 					EmailHelper.getEmailMessage((String)session.getAttribute("BankName"), (String)session.getAttribute("ProductName"), (String)session.getAttribute("ContributionAmount"), date, "C123455") );
	             		String speechText ="Your funds will be transferred in two business days and a confirmation email has been sent. Thank you.";
	             		return SpeechUtil.createAskResponse("Confirmation", speechText);
					}			
         		
             	}else{
             		String msg = WebServiceHelper.makeTiaaServiceCall("FUND", "FUND", 
                 			WebServiceHelper.buildRequestForServiceCall(session, "accounts"), "POST", "retrieve-accounts");
                 	log.info(msg);
                 	session.setAttribute("RetrieveServiceResponse", msg);
                 	return SpeechUtil.createAskResponse("FUNDING Accounts", createResponse(msg));
             	}
             } 
             if("AMOUNT".equals(intentName)&& session.getAttribute("TargetAccount")!=null){
             	Double d =getAmountFromRequest(request, session);
             	if(d>=5500){
             		//session.setAttribute("NewAmount", d);
             	
             		String balance = Double.toString(Math.floor(d));
             		log.info(balance);
             		balance = String.format("%.0f", d);
             		//String speech ="You can invest "+ balance+ " dollars but your eligible tax break is 5500 dollars. Do you want to transfer "+  balance+" dollars now?";
             		//return SpeechUtil.createAskResponse("Transfer Limit Reached",speech);
                 	return SpeechUtil.createAskResponse("Transfer Limit Reached","Your transfer limit for the account is 5500 dollars. Do you want to transfer 5500 dollars  ");
             	}else{
             		session.setAttribute("AMOUNTDONE", "Yes");
             		String str = String.valueOf(d);
             		session.setAttribute("ContributionAmount", str);	
             		String msg;
					try {
						msg = WebServiceHelper.makeTiaaServiceCall("PROMPTSOURCE", "PROMPTSOURCE",
								WebServiceHelper.buildRequestForServiceCall(session, "linked"), "POST", "retrieve-linked-accounts");
						log.info("Linked accounts" + msg);
						if(msg.isEmpty()){
							log.info("Linked accounts" + AlexaConstants.second_response);
		             		session.setAttribute("LinkedAccounts", AlexaConstants.second_response);
		             		return SpeechUtil.createAskResponse("Source", createMultipleLinkedAccountResponse(AlexaConstants.second_response,session));
						
						}
	             		session.setAttribute("LinkedAccounts", msg);
	             		return SpeechUtil.createAskResponse("Source", createMultipleLinkedAccountResponse(msg,session));
					} catch (Exception e) {
						log.info("Linked accounts" + AlexaConstants.second_response);
	             		session.setAttribute("LinkedAccounts", AlexaConstants.second_response);
	             		return SpeechUtil.createAskResponse("Source", createMultipleLinkedAccountResponse(AlexaConstants.second_response,session));
					}
             		
                 	
             	}
             }
             if("TIAA".equals(intentName) && session.getAttribute("OTP")!=null){
             	String msg;
				try {
					msg = WebServiceHelper.makeTiaaServiceCall("FUND", "FUND", 
							WebServiceHelper.buildRequestForServiceCall(session, "accounts"), "POST", "retrieve-accounts");
					log.info("the message is " +msg);
					if(msg ==null || msg.isEmpty()){
						session.setAttribute("RetrieveServiceResponse", AlexaConstants.first_response);
		             	session.setAttribute("FundingIntent", "Yes");
		             	return SpeechUtil.createAskResponse("TIAA Balance", createBalanceResponse(AlexaConstants.first_response));
					}
					JSONObject temp = new JSONObject(msg);
					if(temp.getJSONArray("brokerageAccounts")==null|| temp.getJSONArray("brokerageAccounts").length()==0){
						session.setAttribute("RetrieveServiceResponse", AlexaConstants.first_response);
		             	session.setAttribute("FundingIntent", "Yes");
		             	return SpeechUtil.createAskResponse("TIAA Balance", createBalanceResponse(AlexaConstants.first_response));
					
					}
	            	session.setAttribute("RetrieveServiceResponse", msg);
	             	session.setAttribute("FundingIntent", "Yes");
	             	return SpeechUtil.createAskResponse("TIAA Balance", createBalanceResponse(msg));
				} catch (Exception e) {
					session.setAttribute("RetrieveServiceResponse", AlexaConstants.first_response);
	             	session.setAttribute("FundingIntent", "Yes");
	             	return SpeechUtil.createAskResponse("TIAA Balance", createBalanceResponse(AlexaConstants.first_response));
				}	
             }else if ("HelloWorldIntent".equals(intentName)) {
                 return SpeechUtil.getHelloResponse();
             } else if ("AMAZON.HelpIntent".equals(intentName)) {
                 return SpeechUtil.getHelpResponse();
             } else if("FUND".equals(intentName) && session.getAttribute("OTP")!=null){
             	String msg = WebServiceHelper.makeTiaaServiceCall("FUND", "FUND", 
             			WebServiceHelper.buildRequestForServiceCall(session, "accounts"), "POST", "retrieve-accounts");
             	log.info(msg);
             	session.setAttribute("RetrieveServiceResponse", msg);
             	return SpeechUtil.createAskResponse("FUNDING Accounts", createResponse(msg));
             }else if("TARGETACCOUNTS".equals(intentName) && session.getAttribute("RetrieveServiceResponse")!=null){
             	String type = getSelectedAccountFromRequest(request,session);
             	JSONObject obj = new JSONObject((String)session.getAttribute("RetrieveServiceResponse"));
					JSONObject selected = obj.getJSONArray("brokerageAccounts").getJSONObject(0);
					session.setAttribute("AccountCategory", selected.getString("accountCategory"));
					session.setAttribute("AccountType", "Traditional IRA");
					//session.setAttribute("AccountType", selected.getString("accountType"));
					session.setAttribute("PershingAccountNumber", selected.getString("accountNumber"));
					//session.setAttribute("ProductName", selected.getString("productName"));
					session.setAttribute("ProductName", "TIAA Personal Portfolio IRA");
					session.setAttribute("ProductType", "IRA");
					//session.setAttribute("ProductType", selected.getString("productType").toUpperCase());
					session.removeAttribute("RetrieveServiceResponse");	
             	if(type!=null){
             		if("Personal Portfolio".equalsIgnoreCase(type)){		
                 	}	
                 	session.setAttribute("TargetAccount", type);
                 	return SpeechUtil.createAskResponse("TIAAFUNDING-PROMPT_AMOUNT","How much do you want to transfer to your " + type +" account");
             	}else if(session.getAttribute("TargetAccount")!=null){
             		session.removeAttribute("FundingIntent");
         			return SpeechUtil.createAskResponse("TIAAFUNDING-PROMPT_AMOUNT","How much do you want to transfer to your " + (String)session.getAttribute("TargetAccount") +" account");
         		}else{
             		return SpeechUtil.createTellResponse("DefaultSpeech", "I am not sure how to help you on this.");
             	}
             }else{
             	return SpeechUtil.createAskResponse("DefaultSpeech", "I am not sure how to help you on this.");
             }
        }catch(JSONException e){
        	log.error(e.getMessage());
        	e.printStackTrace();
        }catch(TwilioRestException e){
        	log.error(e.getMessage());
        	e.printStackTrace();
        }catch(MessagingException e){
        	log.error(e.getMessage());
        	e.printStackTrace();
        }
        return SpeechUtil.createTellResponse("DefaultSpeech", "I am not sure how to help you on this.");
    }
    
    public void loadSessionWithParticipantData(Session session,String response) throws JSONException{
    	
		JSONObject object = new JSONObject(response);
    	JSONObject participant = object.getJSONObject("participant");
    	JSONObject id = participant.getJSONObject("identification");
    	session.setAttribute("pin", id.getString("pin"));
    	session.setAttribute("ssn", id.getString("ssn"));
    	JSONObject address = participant.getJSONObject("address");
    	session.setAttribute("city", address.getString("townName"));
    	session.setAttribute("country", address.getString("isoCntryName"));
    	session.setAttribute("state", address.getString("countrySubDivision"));
    	session.setAttribute("addressType", address.getString("addressType"));
    	session.setAttribute("zipcode", address.getString("postalCode"));
    	session.setAttribute("addressline1", address.getString("addressLine1"));
    	session.setAttribute("addressid", address.getString("addressID"));
    	session.setAttribute("gender", participant.getString("gender"));
    	session.setAttribute("email", participant.getString("email"));
    	String[] array = participant.getString("birthDate").split(" ");
    	session.setAttribute("birthdate", array[0]);
    	JSONObject phone = participant.getJSONObject("phone");
    	session.setAttribute("areaCode", phone.getString("areaCode"));
    	session.setAttribute("phoneNumber", phone.getString("phoneNumber"));
    	JSONObject person = participant.getJSONObject("person");
    	session.setAttribute("firstName", person.getString("firstName"));
    	session.setAttribute("lastName", person.getString("lastName"));
		session.setAttribute("middleName", person.getString("middleName"));
    }
    
public void hardCodeWithParticipantData(Session session) throws JSONException{
    	
		//JSONObject object = new JSONObject(response);
    	//JSONObject participant = object.getJSONObject("participant");
    	//JSONObject id = participant.getJSONObject("identification");
    	session.setAttribute("pin", "7887898");
    	session.setAttribute("ssn", "666455746");
    	//JSONObject address = participant.getJSONObject("address");
    	session.setAttribute("city", "CHARLOTTE");
    	session.setAttribute("country", "UNITED STATES");
    	session.setAttribute("state", "NC");
    	session.setAttribute("addressType", "ResidenceAddress");
    	session.setAttribute("zipcode", "28262");
    	session.setAttribute("addressline1", "8625 ANDREW CARNEGIE BLVD");
    	session.setAttribute("addressid", "110042247808357858");
    	session.setAttribute("gender", "U");
    	session.setAttribute("email", "chaithanya.aduru@tiaa.org");
    	//String[] array = participant.getString("birthDate").split(" ");
    	session.setAttribute("birthdate", "1940-10-10");
    	//JSONObject phone = participant.getJSONObject("phone");
    	//session.setAttribute("areaCode", phone.getString("areaCode"));
    	session.setAttribute("phoneNumber", "3094621042");
    	//JSONObject person = participant.getJSONObject("person");
    	session.setAttribute("firstName","L");
    	session.setAttribute("lastName", "ELVARD");
		session.setAttribute("middleName", "D");
    }
    
    
public String createMultipleLinkedAccountResponse(String msg,Session session){
 	StringBuilder sb = new StringBuilder();
	sb.append("You have ");
	try {
		JSONObject obj = new JSONObject(msg);
		JSONArray array = obj.getJSONArray("linkedBanks");
		if(array.length()==0){
			return "You have three linked accounts. From which account do you want to transfer? Bank of America Checking account, Premier Delmarva Bank and trust account, Capital one bank checking account";
		}
		JSONArray newArray = new JSONArray();
		if(array.getJSONObject(0).getString("bankName").equalsIgnoreCase(array.getJSONObject(1).getString("bankName"))){
			newArray.put(array.getJSONObject(0));
			newArray.put(array.getJSONObject(2));
			newArray.put(array.getJSONObject(3));
		}else{
			newArray.put(array.getJSONObject(0));
			newArray.put(array.getJSONObject(1));
			newArray.put(array.getJSONObject(2));
		}
		
		session.setAttribute("mlinkedBanks", newArray.toString());
		sb.append(newArray.length() + " linked accounts. ");
		sb.append("From which account do you want to transfer?  ");
		
		for(int i=0;i<newArray.length();i++){
			JSONObject temp = newArray.getJSONObject(i); 
			sb.append(temp.getString("bankName").replace("NA", "").replace(",", "").replace("&", "and") + " " + temp.getString("accountType")+ " "+ "account");
			sb.append(",");
			sb.append(" ");
		}
			
	} catch (JSONException e) {
		e.printStackTrace();
	}
	return "You have three linked accounts. From which account do you want to transfer? Bank of America Checking account, Premier Delmarva Bank and trust account, Capital one bank checking account";
}
    public void createRetrieveAccountResponse(String msg){
    	try {
    	JSONObject object = new JSONObject(msg);
    	StringBuilder sb = new StringBuilder();
    	JSONObject mock = new JSONObject();
		mock.put("productName","Traditional IRA account");
    	
		JSONArray array = object.getJSONArray("brokerageAccounts");
		array.put(mock);
		if(array.length()==1){
			sb.append("You have one account. Do you want to transfer to your "+ array.getJSONObject(0).getString("productName").replace("TIAA", " "));
		}
	} catch (JSONException e) {
		log.error(e.toString(),e);
	}
    }
    public String createResponse(String msg){
    	StringBuilder sb = new StringBuilder();
    	sb.append("You have ");
    	try {
			JSONObject obj = new JSONObject(msg);
			JSONObject mock = new JSONObject();
			mock.put("productName","Traditional IRA account");
			mock.put("accountNumber", "N81672786");
			JSONArray array = obj.getJSONArray("brokerageAccounts");
			array.put(mock);
			HashSet<String> accounts = new HashSet<String>();
			accounts.add("A58003103");
			accounts.add("A58003418");
			accounts.add("A58003889");
			accounts.add("A58010470");
			accounts.add("A58014332");
			accounts.add("A58030650");
			
			sb.append("2"+ " accounts. To which account do you want to transfer ? ");
			for(int i=0;i<array.length();i++){
				JSONObject temp = array.getJSONObject(i);
				if(!accounts.contains(temp.getString("accountNumber"))){
					String name = temp.getString("productName").replace("TIAA", " ");
					if(array.length()==1){
						sb.append(name + " , ");
						break;
					}
					if(i==array.length()-1){
						 sb.append(" or " + name);
					}else{
						sb.append(name + " , ");
					}
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
    	return sb.toString();
    }
    
    public String createBalanceResponse(String msg){
    	StringBuilder sb = new StringBuilder();
    	sb.append("Your total balance is  ");
    	
    	try {
			JSONObject obj = new JSONObject(msg);
			sb.append(obj.getString("totalBalance") + " dollars.");
			sb.append("  You are eligible to contribute to your Traditional IRA account ending in (5 7 9 0) for the year (20 17). Do you wish to contribute now? ");
		} catch (JSONException e) {
			e.printStackTrace();
		}
    	return sb.toString();
    }
    
    public HashMap<String,String> getResponse(String response){
    	HashMap<String, String> map = new HashMap<String, String>();
    	log.info(response);
    	JSONObject obj;
		try {
			obj = new JSONObject(response);
			map.put("data",obj.getString("data"));
			map.put("speech", obj.getString("speech"));
		}
		catch (JSONException e) {
			log.error(e.toString());
		}
		return map;
    }

    
 
    
    
    public double getAmountFromRequest(IntentRequest request,Session session){
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	String slotValue=null;
    	String slotName= null;
        for(Map.Entry<String, Slot> entry : slotMap.entrySet())
        {  
            Slot slot = (Slot)entry.getValue();
            slotName = slot.getName();
            slotValue = slot.getValue();
        }
        session.setAttribute("Amount", slotValue);
        Double d = 0.0;
    	if("Number".equalsIgnoreCase(slotName)){
    		d= Double.valueOf(slotValue);
    	}
    	return d;
    }
    
    public String getPromptFromRequest(IntentRequest request,Session session){
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	String slotValue=null;
   
        for(Map.Entry<String, Slot> entry : slotMap.entrySet())
        {  
            Slot slot = (Slot)entry.getValue();
            log.info(slot.getValue());
            slotValue = slot.getValue();
        }
        
    	return slotValue;
    }
    //startDate
    //endDate
    public String getPromptFromCalendarRequestForTIAA(IntentRequest request,Session session) throws JSONException, ParseException{
    	JSONObject calendarObject = new JSONObject();
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	for(Map.Entry<String, Slot> entry:slotMap.entrySet()){
    		Slot slot = (Slot)entry.getValue();
    		if("CalendarDateSlot".equalsIgnoreCase(slot.getName())){
    			if(slot.getValue()!=null){
    				calendarObject.put("startDate", slot.getValue());
    				
    			}else{
    				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    				Date date = new Date();
    				calendarObject.put("startDate", dateFormat.format(date));
    			}
    		}
    		if("CalendarTimeSlot".equalsIgnoreCase(slot.getName())){
    			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    			if(slot.getValue()!=null){
    				StringBuilder date = new StringBuilder(calendarObject.getString("startDate")).append(" ").append(slot.getValue());
    				Date d = df.parse(date.toString());
    				Calendar gc = new GregorianCalendar();
    				gc.setTime(d);
    				gc.add(Calendar.MINUTE, 15);
    				Date resultdate = new Date(gc.getTimeInMillis());
    				calendarObject.put("startDate", date.toString());
    				calendarObject.put("endDate", df.format(resultdate));
    			}else{
    				StringBuilder date = new StringBuilder(calendarObject.getString("startDate")).append(" ").append("09:00");
    				Date d = df.parse(date.toString());
    				Calendar gc = new GregorianCalendar();
    				gc.setTime(d);
    				gc.add(Calendar.HOUR,8);
    				Date resultdate = new Date(gc.getTimeInMillis());
    				calendarObject.put("startDate", date.toString());
    				calendarObject.put("endDate", df.format(resultdate));
    			}
    		}
    	}
    	calendarObject.put("index", "0");
    	return calendarObject.toString();
    } 
    public String getTIAASlotFactory(IntentRequest request,Session session){
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	if(!slotMap.isEmpty()){
    		 for(Map.Entry<String, Slot> entry : slotMap.entrySet())
             {  
                 Slot slot = (Slot)entry.getValue();
                  if(slot.getValue()!=null && "map".equalsIgnoreCase(slot.getValue())){
                 	return getMapFromRequestForTIAA( request, session);
                 	 
                  }
             }
    		
    	}
    	return getPromptFromRequestForTIAA(request, session);
    }
    public String getMapFromRequestForTIAA(IntentRequest request,Session session){
    	Map<String, Slot> slotMap = request.getIntent().getSlots();

    	if(!slotMap.isEmpty()){
    		StringBuilder builder = new StringBuilder();
            for(Map.Entry<String, Slot> entry : slotMap.entrySet())
            {  
                Slot slot = (Slot)entry.getValue();
                 if(slot.getValue()!=null){
                	 builder.append(slot.getValue());
                	 builder.append(" ");
                	 
                 }
            }
            log.info("Created command is " + builder.toString());
            return builder.toString();
    	}
    	
    	return null;
    }
    
    public String getPromptFromRequestForTIAA(IntentRequest request,Session session){
    	Map<String, Slot> slotMap = request.getIntent().getSlots();
    	boolean yearSlot = false;
    	if(!slotMap.isEmpty()){
    		StringBuilder builder = new StringBuilder();
            for(Map.Entry<String, Slot> entry : slotMap.entrySet())
            {  
                Slot slot = (Slot)entry.getValue();
                 if(slot.getValue()!=null){
                	 builder.append(slot.getValue());
                	 builder.append(" ");
                	 if(slot.getValue().equalsIgnoreCase("2016")){
                		 yearSlot = true;
                	 }
                 }else{
                	 if("ShowDashBoardIntent".equalsIgnoreCase(request.getIntent().getName())&& !yearSlot && !builder.toString().trim().equalsIgnoreCase("dashboard")){
                 		builder.append("2016");
                 	}
                	 return builder.toString();
                 }
            }
            
            if("ShowDashBoardIntent".equalsIgnoreCase(request.getIntent().getName())&& !yearSlot && !builder.toString().trim().equalsIgnoreCase("dashboard")){
        		builder.append("2016");
        	}
            log.info("Created command is " + builder.toString());
            return builder.toString();
    	}
    	
    	return null;
    }
    
    public String getSelectedAccountFromRequest(IntentRequest request,Session session){
    	
    	String slotValue=null;
    	slotValue = (String)session.getAttribute("Slot");
    
    	String accountType =slotValue;
    	String type =null;
    	if("Pension".equalsIgnoreCase(accountType)){
    		type="Pension";	
    	}else if("Retirement".equalsIgnoreCase(accountType)){
    		type ="Retirement";
    	}else if("Personal Portfolio".equalsIgnoreCase(accountType)){
    		type ="Personal Portfolio";
    	}
    	return type;
    }
}
