package helloworld;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazon.speech.speechlet.Session;
import com.amazonaws.util.json.JSONException;
import com.amazonaws.util.json.JSONObject;

public class WebServiceHelper {
	private static final Logger log = LoggerFactory.getLogger(WebServiceHelper.class);
	
	public static SubmitRequest buildRequestForServiceCall(Session session,String operation){
		SubmitRequest submitRequest = new SubmitRequest();
		submitRequest.setPin("7887898");
		if("submit".equalsIgnoreCase(operation)){
			submitRequest.setAccountcategory((String)session.getAttribute("AccountCategory"));
			submitRequest.setAccounttype((String)session.getAttribute("AccountType"));
			submitRequest.setProductname((String)session.getAttribute("ProductName"));
			submitRequest.setProducttype((String)session.getAttribute("ProductType"));
			submitRequest.setPershingaccountnumber((String)session.getAttribute("PershingAccountNumber"));
			submitRequest.setContributionamount((String)session.getAttribute("ContributionAmount"));
			submitRequest.setBankname((String)session.getAttribute("BankName"));
			submitRequest.setBanktype((String)session.getAttribute("BankAccountType"));
			submitRequest.setRoutingnumber((String)session.getAttribute("RoutingNumber"));
			submitRequest.setAccountnumber((String)session.getAttribute("AccountNumber"));
			submitRequest.setPin((String)session.getAttribute("pin"));
			submitRequest.setSsn((String)session.getAttribute("ssn"));
			submitRequest.setCity((String)session.getAttribute("city"));
			submitRequest.setState((String)session.getAttribute("state"));
			submitRequest.setCountry((String)session.getAttribute("country"));
			submitRequest.setAddressline1((String)session.getAttribute("addressline1"));
			submitRequest.setAddressType((String)session.getAttribute("addressType"));
			submitRequest.setZipcode((String)session.getAttribute("zipcode"));
			submitRequest.setAddressid((String)session.getAttribute("addressid"));
			submitRequest.setGender((String)session.getAttribute("gender"));
			submitRequest.setEmail((String)session.getAttribute("email"));
        	submitRequest.setBirthdate((String)session.getAttribute("birthdate"));
			submitRequest.setAreaCode((String)session.getAttribute("areaCode"));
			submitRequest.setPhoneNumber((String)session.getAttribute("phoneNumber"));
			submitRequest.setFirstName((String)session.getAttribute("firstName"));
			submitRequest.setLastName((String)session.getAttribute("lastName"));
			submitRequest.setMiddleName((String)session.getAttribute("middleName"));
		}
		return submitRequest;
	}
	
	public static String makeTiaaServiceCall(String intentName,String slotValue,
			SubmitRequest submitRequest,String method,String operationUrl){
		String inputLine= "";
		try {
			StringBuilder urlBuilder = new StringBuilder();
			urlBuilder.append("https://origin-service-devint.test.tiaa-cref.org/private/api/alexa-account/v1/");
			urlBuilder.append(operationUrl);
			URL url = new URL(urlBuilder.toString());
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestMethod(method);
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Accept", "application/json");
			con.setRequestProperty("tiaa-user-ref", "alexa");
			//con.setRequestProperty("Authorization", "Bearer "+accessToken);
			con.setDoOutput(true);
            OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream());
            ObjectMapper mapper = new ObjectMapper();
            String jsonInString = mapper.writeValueAsString(submitRequest);
            log.info(jsonInString);
            JSONObject obj = new JSONObject(submitRequest);
            writer.write(obj.toString());
            writer.flush();
			BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
			if((inputLine = br.readLine()) !=null){
				return inputLine;
			}
		} catch (MalformedURLException e) {
			if(operationUrl.equalsIgnoreCase("retrieve-accounts")){
				return AlexaConstants.first_response;
			}else if(operationUrl.equalsIgnoreCase("retrieve-linked-accounts")){
				return AlexaConstants.second_response;
			}else{
				return null;
			}
		} catch (ProtocolException e) {
			if(operationUrl.equalsIgnoreCase("retrieve-accounts")){
				return AlexaConstants.first_response;
			}else if(operationUrl.equalsIgnoreCase("retrieve-linked-accounts")){
				return AlexaConstants.second_response;
			}else{
				return null;
			}
		} catch (IOException e) {
			if(operationUrl.equalsIgnoreCase("retrieve-accounts")){
				return AlexaConstants.first_response;
			}else if(operationUrl.equalsIgnoreCase("retrieve-linked-accounts")){
				return AlexaConstants.second_response;
			}else{
				return null;
			}
		}catch(Exception e){
			if(operationUrl.equalsIgnoreCase("retrieve-accounts")){
				return AlexaConstants.first_response;
			}else if(operationUrl.equalsIgnoreCase("retrieve-linked-accounts")){
				return AlexaConstants.second_response;
			}else{
				return null;
			}
		}
		return inputLine;
		
	}
	
	public static String makeTiaaServiceCallForDashBoard(String intentName,String slotValue,
			String method,String operationUrl,String accessToken) throws JSONException{
		String inputLine= "";
		try {
			StringBuilder urlBuilder = new StringBuilder();
			urlBuilder.append("https://origin-service-devint.test.tiaa-cref.org/private/api/alexa-account/v1/");
			urlBuilder.append(operationUrl);
			URL url = new URL(urlBuilder.toString());
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestMethod(method);
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Accept", "application/json");
			con.setRequestProperty("tiaa-user-ref", "alexa");
			con.setRequestProperty("Authorization", "Bearer "+accessToken);
			con.setDoOutput(true);
            OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream());
           
            JSONObject obj = new JSONObject();
            obj.put("command", slotValue);
            log.info(obj.toString());
            writer.write(obj.toString());
            writer.flush();
            writer.close();
			BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
			if((inputLine = br.readLine()) !=null){
				return inputLine;
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (ProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return inputLine;
		
	}

	
}
